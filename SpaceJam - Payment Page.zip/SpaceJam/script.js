// Function to handle the checkout when the "Checkout" button is clicked
function handleCheckout() {
        // Get user input values from input fields
        const securityCode = document.getElementById("cvv").value; // Updated ID for CVV
        const nameOnCard = document.getElementById("name").value; // Updated ID for Name on Card
        const cardNumber = document.getElementById("card-number").value;
        const expiryDate = document.getElementById("expiry-date").value;
        const zipCode = document.getElementById("ZIP").value; // Updated ID for ZIP/Postal code
    
        // Validate user input (you can add more validation here)
        if (!securityCode || !nameOnCard || !cardNumber || !expiryDate || !zipCode) {
            alert("Please fill in all required fields.");
            return;
        }

        // For this example, we'll just display the user input in an alert
        const checkoutDetails = `Security Code: ${securityCode}\nName on Card: ${nameOnCard}\nCard Number: ${cardNumber}\nExpiry Date: ${expiryDate}\nZIP/Postal Code: ${zipCode}`;
        alert("Card Declined, Try Again!\n\n" + checkoutDetails);

        // Clear input fields after successful checkout
        document.getElementById("cvv").value = "";
        document.getElementById("name").value = "";
        document.getElementById("card-number").value = "";
        document.getElementById("expiry-date").value = "";
        document.getElementById("ZIP").value = "";

}

// Add a click event listener to the "Checkout" button
const checkoutButton = document.getElementById(".checkout-button");
checkoutButton.addEventListener("click", handleCheckout);





  function addItemToCart(title, price) {
    var cartRow = document.createElement('div')
    cartRow.classList.add('cart-row')
    var cartItems = document.getElementsByClassName('cart-items')[0]
    var cartItemNames = cartItems.getElementsByClassName('cart-item-title')
    for (var i = 0; i < cartItemNames.length; i++) {
        if (cartItemNames[i].innerText == title) {
            alert('This item is already added to the cart')
            return
        }
    }
    var cartRowContents = `
        <div class="cart-item cart-column">
            <span class="cart-item-title">${title}</span>
        </div>
        <span class="cart-price cart-column">${price}</span>
        <div class="cart-quantity cart-column">
            <input class="cart-quantity-input" type="number" value="1">
            <button class="btn btn-danger" type="button">REMOVE</button>
        </div>`
    cartRow.innerHTML = cartRowContents
    cartItems.append(cartRow)
    cartRow.getElementsByClassName('btn-danger')[0].addEventListener('click', removeCartItem)
    cartRow.getElementsByClassName('cart-quantity-input')[0].addEventListener('change', quantityChanged)
}

addItemToCart('Day trip to Venus', '4.86')