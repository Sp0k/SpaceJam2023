function listChange(id, cName) {
    var i, lists, button;
    console.log("here");
    lists = document.getElementsByClassName("container");
    for (i = 0; i < lists.length; i++) {
        lists[i].classList.remove("active");
    }
    button = document.getElementsByClassName("carrousel");
    for(i = 0; i < button.length; i++) {
        button[i].classList.remove("active");
    }

    document.getElementById(id).classList += " active";
    document.getElementById(cName).classList += " active";
}